# 星穹航天 (CosmoFrontier) — 前沿航天动态与关键词订阅推送

前沿航天探索资讯聚合与实时发射全景追踪应用，支持多维度前沿航天动态流、倒计时全景看板、自定义关键词订阅与系统级/应用内即时推送提醒。

### User Review & Critical Decisions

> [!IMPORTANT] 
> 在阶段一需求澄清中，已明确以下核心产品定位与交互体验规范：

- **已确认信息覆盖维度**: 综合涵盖前沿航天科技要闻、空间站科研突破与全球火箭发射倒计时全景（包含 SpaceX 星舰、长征系列、NASA Artemis 等最新动态）。
- **已确认推送与提醒机制**: 支持 Android 系统通知栏即时横幅推送（基于 `POST_NOTIFICATIONS` 权限与 NotificationChannel）与应用内未读红点/订阅动态即时横幅通知。
- **已确认视觉界面风格**: 深空未来科技风（Deep Cosmic Void 黑色与深曜岩蓝底色，搭配霓虹电光青/星云橙对比高亮、半透明玻璃拟态卡片与科技仪表盘元素）。
- **开放决策与默认推荐**: 
  - 本地离线高可用缓存与预置航天前沿数据库：首屏即时加载最新航天事件与发射日程，同时集成一键在线刷新与离线 Room 数据库持久化存储订阅关键词及收藏夹。
  - 模拟与真实后台推送检测：支持后台周期性定时任务与实时模拟测试推送按钮，便于用户在任意测试环境下立即验证关键词命中与通知触发流程。

---

### 1. Overview & Core Concept

- **What It Does**: 
  「星穹航天 (CosmoFrontier)」是一款面向航天爱好者、科研人员及科技极客的高颜值 Android 移动端前沿航天资讯雷达。用户可实时浏览全球航天重大突破、空间探测器动态与载人航天进展；全景查看即将发射的火箭任务与发射场倒计时；设置自定义关注关键词（如“星舰”、“嫦娥”、“天宫”、“SpaceX”、“可重复使用”等），一旦有匹配的新航天动态更新，系统将第一时间通过系统通知栏和应用内通知中心推送预警。
- **Target Audience / Persona**: 
  关注人类探索宇宙进程的航天发烧友、商业航天从业者、高校科研学子及科技数码爱好者。
- **Key Value**: 
  摆脱碎片化信息噪音，实现“精准关键词雷达订阅 + 零延迟推送 + 沉浸式深空控制台美学体验”。

---

### 2. User Experience & Visual Design

#### 2.1 Key User Flows
1. **浏览与刷新 (Discovery Flow)**:
   - 用户打开应用，首屏顶部为“深空航天雷达”即时动态看板，展示今日最新突发要闻与最近一次火箭发射倒计时卡片。
   - 下拉即可实时刷新前沿资讯流，支持按分类标签（全部、深空探测、载人航天、商业运载火箭、空间科学）快速筛选。
2. **关键词订阅与推送 (Keyword Subscription & Push Flow)**:
   - 切换至“雷达订阅”面板，用户可快捷添加关注词（如“星舰 / Starship”、“长征十号”、“月球基地”），也可直接从热门航天标签云中一键点选。
   - 用户可开启/关闭系统通知开关（动态申请 Android 13+ 通知权限）。
   - 资讯刷新或后台命中时，应用自动判定文章标题与摘要中的关键词匹配度，发出系统通知栏横幅提醒并记录在“推送动态历史”中。
   - 提供“模拟即时测试推送”与“立即匹配扫描”功能，方便用户即刻验证通知效果。
3. **发射全景与倒计时 (Launch Panorama Flow)**:
   - 切换至“发射中心”全景面板，按发射时间轴展示全球各航天发射场（文昌、肯尼迪航天中心、博卡奇卡星舰基地等）的任务名称、运载火箭型号、载荷与倒计时时钟。
4. **详情探索与收藏 (Detail & Bookmark Flow)**:
   - 点击任一资讯或发射卡片进入全景详情页，查看完整任务背景、关键指标规格及技术亮点，支持一键收藏至本地收藏库。

#### 2.2 Visual Identity & Theme
- **Aesthetic Direction**: 深空未来主义 (Deep Cosmic Futurism)。以浩瀚深空为背景，融合天文观测台仪表盘的高精度感与科技微光发光质感。
- **Color Palette & Mood**:
  - `Background`: 深邃虚空黑 `#0B0E14` 与暗夜曜石蓝 `#101726`。
  - `Surface / Card`: 半透明曜石灰蓝 `#182234`，边缘带柔和冷光描边 `#223554`。
  - `Primary / Accent`: 电光星芒青 `#00E5FF`（代表前沿科技信号）。
  - `Secondary Accent`: 推进器火光橙 `#FF6D00` / 激光红 `#FF3D71`（用于发射倒计时与紧急突破预警）。
  - `Text Hierarchy`: 高对比主文本纯白 `#F0F4F8`，次级说明天体银 `#94A3B8`，科技微光标签 `#38BDF8`。
- **Typography & Hierarchy**:
  - 核心数字与倒计时采用科技等宽风格排版（Monospace / Bold）。
  - 标题字号 20sp–24sp 醒目加粗，正文 14sp–15sp 舒适行距（Line-height 1.5），元数据使用 12sp 胶囊标签。
- **Interactive Feedback & Motion**:
  - 交互点击伴随细腻涟漪反馈与微光高亮。
  - 倒计时数字具备呼吸动态，分类切换具备平滑滑动指示胶囊。
  - 通知授权与订阅添加提供流畅的底部弹窗与触觉振动反馈提示。

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: 资讯数据源架构与实时刷新保障**:
  - *Chosen Approach*: 采用本地预置海量丰富且权威的航天前沿数据库作为底座，同时构建联网实时资讯抓取与聚合解析器（支持 Spaceflight News / 航天重大突破动态与前沿发射事件），支持平滑下拉刷新和离线秒开降级。
  - *Why*: 确保无论设备网络状况如何，用户打开应用即刻拥有完整且详实的航天信息流，避免因第三方接口超时或无网导致界面空白。
  - *Alternatives Considered*: 仅依赖纯静态数据（无法满足“实时刷新”与“新推送”需求）或仅依赖外部单个可能跨域/受限的 API（稳定性低）。
- **Decision 2: 关键词订阅与本地持久化引擎**:
  - *Chosen Approach*: 使用已集成的 Android Room 数据库（`androidx.room.ktx` / `room-runtime`）持久化存储用户订阅的关键词规则、已接收推送历史与收藏文章。
  - *Why*: 订阅规则与推送记录属于纯用户专属本地数据，响应极速、隐私安全且在无网络时完整可用。
- **Decision 3: 推送通知实现机制**:
  - *Chosen Approach*: 结合 Android 原生 `NotificationManagerCompat`、`NotificationChannel` 和前台即时扫描广播，提供完整的系统状态栏通知呈现，同时在应用内常驻“雷达预警消息中心”。
  - *Why*: 真实满足用户随时接收系统通知栏横幅的需求，在不同 Android 版本（包括 Android 13+ 的 `POST_NOTIFICATIONS` 运行时权限）下均能安全稳定运行。

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CosmoFrontier UI Layer                          │
│                                                                        │
│   ┌─────────────────────┐  ┌─────────────────────┐  ┌───────────────┐  │
│   │   前沿航天头条资讯   │  │   全球火箭发射看板   │  │  关键词订阅库 │  │
│   │   (NewsStreamScreen)│  │   (LaunchPadScreen) │  │(RadarSubScreen│  │
│   └──────────┬──────────┘  └──────────┬──────────┘  └───────┬───────┘  │
│              │                        │                     │          │
│              └───────────────────┬────┴─────────────────────┘          │
│                                  ▼                                     │
│                    SpaceViewModel & NotificationHub                    │
│             (StateFlow<NewsUiState>, StateFlow<SubState>)              │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Data & Repository Layer                         │
│                                                                        │
│   ┌────────────────────────────────┐  ┌────────────────────────────┐   │
│   │     SpaceNewsRepository        │  │   SubscriptionRepository   │   │
│   │ (Local Preload + Online Sync)  │  │ (Room DB: Keywords & Alerts│   │
│   └──────────────┬─────────────────┘  └─────────────┬──────────────┘   │
└──────────────────┼──────────────────────────────────┼──────────────────┘
                   │                                  │
                   ▼                                  ▼
┌───────────────────────────────────────┐  ┌─────────────────────────────┐
│          Android System API           │  │     Room AppDatabase        │
│   - NotificationChannel ("radar_alert"│  │ - SubscriptionKeywordEntity │
│   - NotificationCompat.Builder        │  │ - AlertHistoryEntity        │
│   - POST_NOTIFICATIONS Permission Flow│  │ - BookmarkedArticleEntity   │
└───────────────────────────────────────┘  └─────────────────────────────┘
```

#### 4.1 Data Models & State
- `SpaceArticle`:
  - `id`: String
  - `title`: String (文章标题)
  - `summary`: String (前沿突破摘要)
  - `source`: String (发布机构，如 中国国家航天局、NASA、SpaceX、ESA、蓝箭航天等)
  - `category`: SpaceCategory (深空探测、载人航天、运载火箭、空间科学、商业航天)
  - `publishedAt`: String / Long
  - `imageUrl`: String
  - `readTimeMinutes`: Int
  - `tags`: List<String>
  - `isFeatured`: Boolean
- `RocketLaunch`:
  - `id`: String
  - `missionName`: String
  - `rocketName`: String
  - `launchSite`: String
  - `scheduledTime`: Long (毫秒时间戳，用于倒计时)
  - `status`: LaunchStatus (准备就绪、燃料加注、倒计时中、发射成功)
  - `payloadDetails`: String
- `SubscriptionKeyword`:
  - `keyword`: String (关注词)
  - `createdAt`: Long
  - `matchCount`: Int
  - `isEnabled`: Boolean
- `AlertNotificationItem`:
  - `id`: Long
  - `keyword`: String
  - `articleTitle`: String
  - `timestamp`: Long
  - `isRead`: Boolean

#### 4.2 Interactive Component & State Mapping
- **新闻资讯流**: 支持分类过滤器切换、关键字搜索栏、下拉刷新指示器、点击卡片展开详情弹窗/详情页面。
- **关键词订阅管理**:
  - 输入框添加新关键词（输入校验与去重）。
  - 推荐热门关键词药丸胶囊（点击一键订阅/取消）。
  - 开关控制单个关键词推送提醒状态。
  - “测试推送触发”按钮，即刻调用系统通知服务发送测试横幅。
- **通知服务与权限控制器**:
  - 自动检测 Android 13+ `POST_NOTIFICATIONS` 授权状态；若未授权，弹出温和引导条与系统授权对话框。
  - 发送通知时绑定 PendingIntent，点击通知可直接唤起应用并定位到对应资讯详情。
